import { useState } from "react"
import { Link, Navigate } from "react-router-dom"
import { useNavigate } from "react-router-dom";

const Login=()=>{
    const navigate = useNavigate();
    let [user,setUser]=useState({username:'',password:''});
  const login=(event)=>{
    event.preventDefault();
        fetch('http://localhost:5190/api/Account/login',{
            method:'POST',
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify(user)
        }).then(res=>res.json()).then(data=>{
            console.log('token:',data.token);
            localStorage.setItem('token',data.token);
            navigate('/');
            console.log('logged-in')
            console.log(user)
        }).catch(err=>{
            console.log('Invalid Credentials:',err)
        })
    }
    const txtHandler=(e)=>{
        let name=e.target.name;
        let value=e.target.value;
        setUser((prevData)=>(
            {...prevData,[name]:value}
        ));

    }
    return(
        <div>
        <form className="form" onSubmit={login} >
            <div className="row">
                <div className="col-md-6">
                    <label className="form-label">UserName:</label>
                </div>
                <div className="col-md-6">
                    <input type="text" className="form-control" name="username" value={user.username} onChange={txtHandler} />
                </div>
            </div>
            <div className="row">
                <div className="col-md-6">
                    <label className="form-label">Password:</label>
                </div>
                <div className="col-md-6">
                    <input type="password" className="form-control" name="password" value={user.password} onChange={txtHandler}/>
                </div>
            </div>
            <div className="row">
                <div className="col-md-6">
                    <input type="submit" value="Login"className="btn btn-warning"  />
                </div>
            </div>
            {/* <Link to="/register"className="btn btn-info" >Register</Link> */}
        </form>
        </div>
    )
}
export default Login;