import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const EmployeeFormControl = () => {
  const [formData, setFormData] = useState({
    employeeid: 0,
    firstname: "",
    lastname: "",
    email: "",
    phonenumber: "",
    address: "",
    city: "",
    country: "",
    yearsofexperience: 0,
    profilepicturefile: null, 
    dateofbirth: "",
    skills: "",
  });

  const [formError, setFormError] = useState({
    firstname: "First name is required",
    email: "Email is required",
    phonenumber: "Phone number is required",
  });

  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate(); 

 
  const validateForm = () => {
    return Object.values(formError).every((err) => err.length === 0);
  };

  
  const submitHandler = (event) => {
    event.preventDefault();

    if (validateForm()) {
      const data = new FormData();

      
      Object.keys(formData).forEach((key) => {
        if (key === "profilepicturefile" && formData[key]) {
          data.append(key, formData[key]); 
        } else {
          data.append(key, formData[key]);
        }
      });

      
      fetch("http://localhost:5190/api/Home/create", {
        method: "POST",
        body: data, 
      })
        .then((res) => {
          if (!res.ok) throw new Error(`Server error: ${res.status}`);
          return res.json();
        })
        .then((data) => {
          console.log("Employee added successfully:", data);
          alert("Employee added successfully!");
          navigate("/employee-list"); 
        })
        .catch((err) => {
          console.error("Error adding employee:", err);
          alert("Failed to add employee. Please check your input.");
        });
    } else {
      setErrorMessage(
        Object.values(formError).map(
          (err, index) => err && <li key={index}>{err}</li>
        )
      );
    }
  };

 
  const inputChangeHandler = (event) => {
    const { name, value, type } = event.target;

    setFormData((prev) => ({
      ...prev,
      [name]: type === "file" ? event.target.files[0] : value, 
    }));

    
    setFormError((prev) => {
      const updatedError = { ...prev };
      switch (name) {
        case "firstname":
          updatedError.firstname = value.trim().length === 0 ? "First name is required" : "";
          break;
        case "email":
          updatedError.email = !value.match(
            /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
          )
            ? "Invalid email format"
            : "";
          break;
        case "phonenumber":
          updatedError.phonenumber =
            value.length !== 10 ? "Phone number must be 10 digits" : "";
          break;
        default:
          break;
      }
      return updatedError;
    });
  };

  return (
    <div className="container">
      <h4>Employee Registration Form</h4>
      <form className="form" onSubmit={submitHandler}>
        <div className="form-group row">
          <label className="col-md-4 control-label">Employee ID:</label>
          <div className="col-md-8">
            <input
              type="number"
              className="form-control"
              name="employeeid"
              onChange={inputChangeHandler}
              value={formData.employeeid}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">First Name:</label>
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              name="firstname"
              onChange={inputChangeHandler}
              value={formData.firstname}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Last Name:</label>
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              name="lastname"
              onChange={inputChangeHandler}
              value={formData.lastname}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Email:</label>
          <div className="col-md-8">
            <input
              type="email"
              className="form-control"
              name="email"
              onChange={inputChangeHandler}
              value={formData.email}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Phone Number:</label>
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              name="phonenumber"
              onChange={inputChangeHandler}
              value={formData.phonenumber}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Profile Picture:</label>
          <div className="col-md-8">
            <input
              type="file"
              className="form-control"
              name="profilepicturefile"
              onChange={inputChangeHandler}
              accept="image/*"
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Date of Birth:</label>
          <div className="col-md-8">
            <input
              type="date"
              className="form-control"
              name="dateofbirth"
              onChange={inputChangeHandler}
              value={formData.dateofbirth}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Skills:</label>
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              name="skills"
              onChange={inputChangeHandler}
              value={formData.skills}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">City:</label>
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              name="city"
              onChange={inputChangeHandler}
              value={formData.city}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Years Of Experience:</label>
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              name="yearsofexperience"
              onChange={inputChangeHandler}
              value={formData.yearsofexperience}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Address:</label>
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              name="address"
              onChange={inputChangeHandler}
              value={formData.address}
            />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-md-4 control-label">Country:</label>
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              name="country"
              onChange={inputChangeHandler}
              value={formData.country}
            />
          </div>
        </div>
        <div className="form-group row">
          <div className="col-md-12 text-center">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </div>
      </form>
      <ul>{errorMessage}</ul>
    </div>
  );
};

export default EmployeeFormControl;
