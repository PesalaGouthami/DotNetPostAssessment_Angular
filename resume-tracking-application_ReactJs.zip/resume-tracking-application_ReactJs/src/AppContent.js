import React from 'react';
import { BrowserRouter, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import Login from './Login';
import { Link } from 'react-router-dom';
import EmployeeFormControl from './EmployeeFormControl';
import EmployeeList from './EmployeeList';
import { useEffect,useState } from 'react';
import EditEmployee from './EditEmployee';
import ProtectedRoute from './ProtectedRoute';

const Home = () => {
  return (
    <div className="container my-5">
      <header className="text-center">
        <h1 className="text-primary">Welcome to Resume Tracker</h1>
        <p className="lead">Efficiently manage and track resumes with ease.</p>
      </header>

      <section className="mt-4">
        <div className="row">
          <div className="col-md-6">
            <h3>Features</h3>
            <ul>
              <li>Upload and store resumes securely.</li>
              <li>Track Employees Applications</li>
              <li>Generate resumes</li>
            </ul>
          </div>
          <div className="col-md-6">
            <h3>Get Started</h3>
          </div>
        </div>
      </section>
    </div>
  );
};



const AppContent=()=>{
    const [employees,setEmployees]=useState([])
    const token=localStorage.getItem("token");
    const navigate=useNavigate();
    useEffect(()=>{
        if(token){
        fetch("http://localhost:5190/api/Home/getAllEmps",{
            headers:{authorization:`Bearer ${token}`}
        }).then(respone=>{
           respone.json().then(data=>{
            setEmployees(data);
           })
        });
    }
    },[]);

    const deleteContact = (id) => {
        if (window.confirm("Want to delete?")) {
          fetch(`http://localhost:5190/api/Home/delete/${id}`, {
            headers:{authorization:`Bearer ${token}`},
            method: "DELETE",
          })
            .then((response) => {
              if (!response.ok) {
                throw new Error(`Failed to delete: ${response.status}`);
              }
              return fetch("http://localhost:5190/api/Home/getAllEmps");
            })
            .then((res) => {
                if(res===401){
                    alert("You are not authorized");
                }
              if (!res.ok) {
                throw new Error(`Failed to fetch employees: ${res.status}`);
              }
              return res.json();
            })
            .then((data) => {
              setEmployees(data); 
              alert("Employee deleted successfully!");
            })
            .catch((err) => {
              console.error("Error:", err);
              alert("Failed to delete employee or fetch updated employee list.");
            });
        }
      };    
      const logout=()=>{
        if(token){
        localStorage.removeItem("token");
        navigate('/login');
        }
      }  

    return(
        <div>
        {/* <BrowserRouter> */}
        
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
          <div class="container-fluid">
            <div className='col-md-6'>
            <h1>Resume Tracking Application</h1>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse col-md-6" id="navbarText">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="/">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/add-employee">Add Employee</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/employee-list">Employees List</a>
                </li>
                <li class="nav-item" >
                <Link to='/login' className='btn btn-primary'>Login</Link>
                </li>
                <li class="nav-item">
                  <button className='btn btn-danger' onClick={logout}>Logout</button>
                </li>
              </ul>
            </div>
          </div>
        </nav>
    
        <Routes>
            <Route path='/login' element={<Login/>}/>
            <Route element={<ProtectedRoute/>}>
                <Route path='/' element={<Home/>}/>
                <Route path='/add-employee' element={<EmployeeFormControl/>}/>
                <Route path='/employee-list' element={<EmployeeList contacts={employees}  deleteContact={deleteContact}/>}/>
                <Route path='/edit-employee/:id' element={<EditEmployee/>}/>
            </Route>
        </Routes>
        
        {/* </BrowserRouter> */}
        </div>
    )
}
export default AppContent;
