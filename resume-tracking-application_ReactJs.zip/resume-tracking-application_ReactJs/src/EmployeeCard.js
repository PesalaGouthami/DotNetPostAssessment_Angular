import { Link } from "react-router-dom";

const EmployeeCard = ({ contact, deleteContact }) => {
  const getImageUrl = () => {
    return `http://localhost:5190/api/Home/image/${contact.employeeid}`;
  };
  const handleViewResume = () => {
    window.open(`http://localhost:5190/api/Home/download-pdf?id=${contact.employeeid}`, "_blank");
  };

  return (
    <div className="card h-100" style={{ padding: "20px" }}>
      <img
        src={getImageUrl()}
        alt="Employee"
        className="card-img-top"
        style={{ width: "100%", height: "200px", objectFit: "cover" }}
      />
      <div className="card-body">
        <h5 className="card-title">{contact.firstname} {contact.lastname}</h5>
        <div className="card-text">{contact.email}</div>
        <div className="card-text">{contact.phonenumber}</div>
        <div className="card-text">{contact.employeeid}</div>
        <div className="d-flex justify-content-between mt-3">
          <Link to={`/edit-employee/${contact.employeeid}`} className="btn btn-info">
            Edit
          </Link>
          <button onClick={handleViewResume} className="btn btn-primary">
          View Resume
        </button>
          <button
            onClick={() => deleteContact(contact.employeeid)}
            className="btn btn-danger"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default EmployeeCard;
