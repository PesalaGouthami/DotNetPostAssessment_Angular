import React from "react";
import EmployeeCard from "./EmployeeCard";

const EmployeeList = ({ contacts, deleteContact }) => {
  return (
    <div className="container mt-4">
      <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
        {contacts.map((c) => (
          <div key={c.employeeid} className="col">
            <EmployeeCard contact={c} deleteContact={deleteContact} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default EmployeeList;
