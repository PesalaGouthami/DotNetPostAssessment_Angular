import logo from './logo.svg';
import './App.css';
import { Component } from 'react';
import AppContent from './AppContent';
import { BrowserRouter } from 'react-router-dom';

class App extends Component{
  render(){
    return <div>
      <BrowserRouter>
        <AppContent/>
      </BrowserRouter>
    </div>
  }
}

export default App;
